
document.addEventListener("DOMContentLoaded", function() {
    const loginText = document.querySelector("#login");
    const title = document.querySelector("#title");
    const form = document.querySelector("form");
    const emailField = document.querySelector(".input-box:nth-child(2)");

    loginText.addEventListener("click", function(event) {
        event.preventDefault();
        if (title.innerText === "Registration") {
            title.innerText = "Welcome Back!";
            loginText.innerText = "Create an account";
            emailField.style.display = "none";
            form.querySelector(".btn").innerText = "Login";
        } else {
            title.innerText = "Registration";
            loginText.innerText = "Login";
            emailField.style.display = "block";
            form.querySelector(".btn").innerText = "Register";
        }
    });
});
